CREATE DATABASE Course_Evaluation;
Use Course_Evaluation;
CREATE TABLE Student(
	Student_netID varchar(10) NOT NULL primary key,
	password varchar(100) NOT NULL,
	email varchar(100) NOT NULL
);

CREATE TABLE Professor(
	Professor_netID varchar(10) NOT NULL primary key, 
	password varchar(100) NOT NULL,
	email varchar(100) NOT NULL
);

CREATE TABLE Course(
	CourseID varchar(10) NOT NULL primary key,
	Professor_netID varchar(10) NOT NULL, 
	Student_netID varchar(10) NOT NULL,
	Course_Name varchar(100) NOT NULL
);

CREATE TABLE Course_Response(
	CrouseID varchar(10) NOT NULL,
	Instructor_rate INT NOT NULL,
	Instructor_comment varchar(5000),
	Course_rate INT NOT NULL,
	Course_comment varchar(5000)
);